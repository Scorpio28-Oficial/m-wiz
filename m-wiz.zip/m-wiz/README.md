
M-wiz is a bash based script which is officially made for metasploit-framework users of termux from this tool in just one click you can install metasploit, repair it, update it, and backup up it and lot more. This tool works on both rooted Android device and Non-rooted Android device.

## AVAILABLE ON :

* Termux

### TESTED ON :

* Termux

### REQUIREMENTS :
* internet 600 MB
* external storage permission
* storage 1Gb
* 1gb ram

## FEATURES :
* [+] Install Metasploit !
* [+] Updated maintainence !
* [+] Easy for beginners !
* [+] Repairt metasploit !
* [+] FIxed ruby issue !

## INSTALLATION [Termux] :

* `apt-get update -y`
* `apt-get upgrade -y`
* `pkg install python -y`
* `pkg install python2 -y`
* `pkg install git -y`
* `pip install lolcat`
* `cd $HOME`
* `ls`
* `cd m-wiz`
* `ls`
* `bash m-wiz.sh`
```
[+]-- Now you need internet connection to continue further process...
[+]-- You can select any option by clicking on your keyboard
[+]-- Note:- Don't delete any of the scripts included in core directory (folder)
```
## USAGE OPTIONS [Termux] :

__METAPLOIT INSTALL__ :
- From this option you can install metasploit-framework in termux application without any issue in just one click and the installation can take time upto 30 minutes.

__IN METASLOIT v1.3__ :
- The low end device is supported to run metasploit a new version selection option has been added for 4.4 version devices and 6.0 version devices

__METASPLOIT REPAIR__ :
- From this option you can repair metasploit-framework if it's not working properly in termux application.

__METASPLOIT BACKUP__ :
- From this option you can backup your metasploit-framework into your device internal storage without any issue without losing any data.

__METASPLOIT RESTORE__ :
- From this option you can restore your backed up metasploit-framework from your internal storage.

__METASPLOIT DELETE__ :
- From this tool you can delete your old metasploit-framework from your termux application easyli.

__UPDATE__ :
- From this option you can update m-wiz tool if updates are available for that.

__ABOUT__ :
- From this option you can read about author.

__CHAT__ :
- From this option you can chat with coder.

__SUBSCRIBE__ :
- From this option you can subscribe channel.

__FOLLOW__ :
- From this option you can follow technical mundeer

__EXIT__ :
- From this option you can exit from m-wiz tool

## SCREEN SHOTS [Termux]


## WATCH VIDEO [Termux]
technical mundeer 
## CONNECT WITH US :

## BUY ME A COFFEE :
